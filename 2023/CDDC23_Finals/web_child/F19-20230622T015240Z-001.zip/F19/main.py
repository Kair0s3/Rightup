from flask import Flask, request, render_template, render_template_string, jsonify, Response
import jwt
from functools import wraps
from datetime import datetime, timedelta
import socket
import os
import re

app = Flask(__name__)

flag = 'This is Fake'
admin_pw= "admin password"
filtering = ["os","open","decode","_", ".","request","[","]","join","%","\\x5f", "\\137", "\\u005f", "\\U0000005F"]

app.config["JWT_SECRET_KEY"] = "JWT_Secret_Key"

def check_access_token(access_token):
    try:
        payload = jwt.decode(access_token, app.config['JWT_SECRET_KEY'], "HS256")
    except jwt.ExpiredSignatureError:
        payload = None 
    except jwt.InvalidTokenError:
        payload = None
    
    return payload

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwagrs):
        access_token = request.cookies.get('token')
        if access_token is not None:
            payload = check_access_token(access_token)
            if payload is None:
                return Response (status=401)

        else:
            return Response(status=401)

        return f(*args, **kwagrs)

    return decorated_function


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@app.route('/login', methods=['POST'])
def login():
    credential = request.json
    user_id = credential['user_id']
    user_pw = credential['user_pw']

    if user_id == 'admin':
        if user_pw == admin_pw :
            payload = {
                'id': user_id,
                'exp': datetime.utcnow() + timedelta(seconds=60 * 60 * 24) 
            }
            token = jwt.encode(payload, app.config['JWT_SECRET_KEY'], 'HS256')

            return jsonify({'result': 'success', 'access_token': token.decode('UTF-8')})
        
    else:
        payload = {
            'id': user_id,
            'exp': datetime.utcnow() + timedelta(seconds=60 * 60 * 24)
        }
        token = jwt.encode(payload, app.config['JWT_SECRET_KEY'], 'HS256')

        return jsonify({'result': 'success', 'access_token': token.decode('UTF-8')})


@app.route('/home', methods=['GET', 'POST'])
@login_required
def home():
  token = check_access_token(request.cookies.get('token'))
  id = token['id']
  
  for word in filtering:
      if word in id:
          return "<h1> Filtered </h1>"

  template = '''
  <h1/> Welcome! {} </h1>
'''.format(id)
  return render_template_string(template)

@app.route('/flag', methods=['GET', 'POST'])
def get_flag():
	return flag

@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin():
    access_token = request.cookies.get('token') 
    payload = check_access_token(access_token)
    if payload['id'] != 'admin':
        return Response(status=401)

    cmd = request.values.get('cmd')
    if cmd == 'ping':
        ip_addr = request.values.get('ip_addr')
        if socket.gethostbyname(ip_addr) != None:
            ret = os.popen('ping ' + ip_addr + ' -c 5').read()

            return '''
            <h1>{}</h1>
            '''.format(ret)
        
        return '''
        <h1>Invalid Address</h1>
        '''
    elif cmd == 'ifconfig':
        ret = os.popen('ifconfig')
        
        return '''
            <h1>{}</h1>
            '''.format(ret)
    
    elif cmd == 'file_check':
        file_name = request.values.get('file_name')
        filter = re.findall(r'flag', file_name)
        if filter != []:
            return '''
            <h1>Error</h1>
            '''
        filter = re.findall(r'[<>()\`\'"$&|;!\t\n]', file_name)
        if filter == []:
            ret = os.popen('cat ' + file_name)
            return '''
            <h1>{}</h1>
            '''.format(ret)
        
    else:
        return'''
        <h1>admin</h1>
        '''

if __name__ == '__main__':
    app.run()
